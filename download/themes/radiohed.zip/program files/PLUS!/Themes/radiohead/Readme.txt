thank you for downloading this file


To install this theme simply unzip the contents of radiohead theme.zip into the
C:\ or whatever the drive with your desktop theme program might be. 
For best results I recomend you put the font file (Sqr721be.ttf) into your 
windows\fonts directory and there you are.

Then select the radiohead(high colour)theme in plus and your ready to go! 

Any questions or thanx send them to me Nick Holden at hellfire@globalnet.co.uk
money welcome :)

Enjoy this useless adittion to your computer