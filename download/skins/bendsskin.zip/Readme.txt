RADIOHEAD SKIN (bends theme)
hola...glad ye downloaded this skin.

winamp and mp3's are the greatest! (right behind my favorite band--radiohead). i recently discovered these really cool skins that you can download for winamp.
i couldn't find any radiohead skins myself...so i decided to make one.

now that you've unzipped this folder,
just slip the 'radiohead' folder into your winamp\skins\ directory.  then next time you open winamp, hit ALT + S and choose your new radiohead skin.

please let me know what you think.
thanks,
matt scherdin

email: jolzenpop@aol.com



ps...i also made one for my band if anyone is interested.